#include <stdio.h>
#include <stdbool.h>
#include "headers.h"

int main(){
    play();
}