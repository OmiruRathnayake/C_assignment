#ifndef RAND_UTILS_H
#define RAND_UTILS_H

// Returns a random integer between 0 and 6 inclusive
int rand_int_0_6(void);

#endif
